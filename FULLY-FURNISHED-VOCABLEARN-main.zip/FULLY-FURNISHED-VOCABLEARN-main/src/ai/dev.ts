import '@/ai/flows/generate-pronunciation-guide.ts';
import '@/ai/flows/fetch-daily-words.ts';
import '@/ai/flows/generate-daily-quiz.ts';
