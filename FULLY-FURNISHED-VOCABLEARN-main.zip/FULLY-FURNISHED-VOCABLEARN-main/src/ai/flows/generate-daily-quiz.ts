// Use server directive for Next.js
'use server';

/**
 * @fileOverview Generates a daily quiz based on a list of words.
 *
 * This file exports:
 * - `generateDailyQuiz`:  A function that generates a daily quiz.
 * - `GenerateDailyQuizInput`: The input type for the `generateDailyQuiz` function.
 * - `GenerateDailyQuizOutput`: The output type for the `generateDailyQuiz` function.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const GenerateDailyQuizInputSchema = z.object({
  words: z.array(
    z.object({
      word: z.string().describe('The word to be quizzed on'),
      definition: z.string().describe('The definition of the word'),
    })
  ).describe('An array of words and their definitions for the quiz.'),
});
export type GenerateDailyQuizInput = z.infer<typeof GenerateDailyQuizInputSchema>;

const GenerateDailyQuizOutputSchema = z.object({
  quiz: z.string().describe('The generated quiz questions and answers.'),
});
export type GenerateDailyQuizOutput = z.infer<typeof GenerateDailyQuizOutputSchema>;

export async function generateDailyQuiz(input: GenerateDailyQuizInput): Promise<GenerateDailyQuizOutput> {
  return generateDailyQuizFlow(input);
}

const generateDailyQuizPrompt = ai.definePrompt({
  name: 'generateDailyQuizPrompt',
  input: {
    schema: z.object({
      words: z.array(
        z.object({
          word: z.string().describe('The word to be quizzed on'),
          definition: z.string().describe('The definition of the word'),
        })
      ).describe('An array of words and their definitions for the quiz.'),
    }),
  },
  output: {
    schema: z.object({
      quiz: z.string().describe('The generated quiz questions and answers.'),
    }),
  },
  prompt: `You are an expert quiz generator. You will generate a quiz based on the provided words and their definitions.

Words and Definitions:
{{#each words}}
  Word: {{this.word}}
  Definition: {{this.definition}}
{{/each}}

Generate a short quiz using these words. The quiz should test the user's understanding of the words.
Include the answers with the quiz.`, 
});

const generateDailyQuizFlow = ai.defineFlow<
  typeof GenerateDailyQuizInputSchema,
  typeof GenerateDailyQuizOutputSchema
>({
  name: 'generateDailyQuizFlow',
  inputSchema: GenerateDailyQuizInputSchema,
  outputSchema: GenerateDailyQuizOutputSchema,
}, async input => {
  const {output} = await generateDailyQuizPrompt(input);
  return output!;
});

