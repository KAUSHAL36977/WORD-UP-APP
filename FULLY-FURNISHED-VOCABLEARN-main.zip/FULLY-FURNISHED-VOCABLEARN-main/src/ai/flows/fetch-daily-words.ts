'use server';
/**
 * @fileOverview Fetches a list of 10 new and interesting English words daily using AI, optionally filtered by category.
 *
 * - fetchDailyWords - A function that fetches the daily words, optionally filtered by category.
 * - FetchDailyWordsInput - The input type for the fetchDailyWords function, including an optional category.
 * - FetchDailyWordsOutput - The return type for the fetchDailyWords function, containing an array of words with definitions and examples.
 */

import {ai} from '@/ai/ai-instance';
import {z} from 'genkit';

const FetchDailyWordsInputSchema = z.object({
  category: z.string().optional().describe('The category of words to fetch (e.g., Science, Technology, Arts, Literature).'),
});
export type FetchDailyWordsInput = z.infer<typeof FetchDailyWordsInputSchema>;

const FetchDailyWordsOutputSchema = z.object({
  words: z.array(
    z.object({
      word: z.string().describe('The word itself.'),
      definition: z.string().describe('The definition of the word.'),
      example: z.string().describe('An example sentence using the word.'),
      synonyms: z.string().describe('Synonyms of the word'),
      antonyms: z.string().describe('Antonyms of the word'),
    })
  ).describe('An array of words with their definitions and examples, including synonyms and antonyms.'),
});
export type FetchDailyWordsOutput = z.infer<typeof FetchDailyWordsOutputSchema>;

export async function fetchDailyWords(input: FetchDailyWordsInput): Promise<FetchDailyWordsOutput> {
  return fetchDailyWordsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'fetchDailyWordsPrompt',
  input: {
    schema: z.object({
      category: z.string().optional().describe('The category of words to fetch (e.g., Science, Technology, Arts, Literature).'),
    }),
  },
  output: {
    schema: z.object({
      words: z.array(
        z.object({
          word: z.string().describe('The word itself.'),
          definition: z.string().describe('The definition of the word.'),
          example: z.string().describe('An example sentence using the word.'),
          synonyms: z.string().describe('Synonyms of the word'),
          antonyms: z.string().describe('Antonyms of the word'),
        })
      ).describe('An array of words with their definitions and examples, including synonyms and antonyms.'),
    }),
  },
  prompt: `You are a lexicographer curating a list of 10 interesting English words for daily vocabulary improvement.

  Provide a diverse selection of words, including their definitions, example sentences, synonyms, and antonyms.

  The words should be suitable for English language learners who want to expand their vocabulary.

  {{#if category}}
  The words should be related to the category: {{category}}.
  {{/if}}

  Return the words in JSON format.
  `,
});

const fetchDailyWordsFlow = ai.defineFlow<
  typeof FetchDailyWordsInputSchema,
  typeof FetchDailyWordsOutputSchema
>({
  name: 'fetchDailyWordsFlow',
  inputSchema: FetchDailyWordsInputSchema,
  outputSchema: FetchDailyWordsOutputSchema,
}, async input => {
  const {output} = await prompt(input);
  return output!;
});
