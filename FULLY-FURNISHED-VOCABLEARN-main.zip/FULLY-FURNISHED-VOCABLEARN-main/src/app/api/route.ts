'use server';

import {fetchDailyWords} from '@/ai/flows/fetch-daily-words';
import {NextResponse} from 'next/server';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get('category') || undefined;

  try {
    const dailyWords = await fetchDailyWords({ category });
    return NextResponse.json(dailyWords.words);
  } catch (error) {
    console.error('Error fetching words from AI:', error);

    // Fallback words for each category
    let defaultWords;
    switch (category) {
      case 'Science':
        defaultWords = [
          {
            word: "Quantum",
            type: "adjective",
            definition: "Relating to quantum mechanics.",
            example: "Quantum physics is essential for understanding the behavior of subatomic particles.",
            synonyms: "quantal, discrete, atomic",
            antonyms: "continuous, analog, classical"
          },
          {
            word: "Genome",
            type: "noun",
            definition: "The complete set of genes or genetic material present in a cell or organism.",
            example: "The human genome project mapped the entire human genome.",
            synonyms: "genetic code, chromosome set, DNA sequence",
            antonyms: "none"
          },
        ];
        break;
      case 'Technology':
        defaultWords = [
          {
            word: "Algorithm",
            type: "noun",
            definition: "A process or set of rules to be followed in calculations or other problem-solving operations, especially by a computer.",
            example: "The search engine uses a complex algorithm to rank search results.",
            synonyms: "procedure, routine, method",
            antonyms: "randomness, chaos"
          },
          {
            word: "Bandwidth",
            type: "noun",
            definition: "The range of frequencies within a given band or, the amount of data that can be transmitted in a fixed amount of time.",
            example: "Streaming video requires a significant amount of bandwidth.",
            synonyms: "capacity, data rate, throughput",
            antonyms: "limitation, bottleneck"
          },
        ];
        break;
      case 'Arts':
        defaultWords = [
          {
            word: "Chiaroscuro",
            type: "noun",
            definition: "The use of strong contrasts between light and dark, typically in painting, to achieve a sense of volume.",
            example: "Rembrandt is renowned for his use of chiaroscuro in his portraits.",
            synonyms: "shading, contrast, modeling",
            antonyms: "flatness, evenness"
          },
          {
            word: "Aesthetic",
            type: "adjective",
            definition: "Concerned with beauty or the appreciation of beauty.",
            example: "The design of the building is both functional and aesthetic.",
            synonyms: "artistic, tasteful, elegant",
            antonyms: "unattractive, displeasing, ugly"
          },
        ];
        break;
      case 'Literature':
        defaultWords = [
          {
            word: "Epilogue",
            type: "noun",
            definition: "A section or speech at the end of a book or play that serves as a conclusion to what has happened.",
            example: "The epilogue revealed the fates of the main characters years later.",
            synonyms: "afterword, conclusion, postscript",
            antonyms: "prologue, introduction, preface"
          },
          {
            word: "Verse",
            type: "noun",
            definition: "Writing arranged with a metrical rhythm, typically having a rhyme.",
            example: "Shakespeare's plays are written in both prose and verse.",
            synonyms: "poetry, rhyme, stanza",
            antonyms: "prose"
          },
        ];
        break;
      default:
        defaultWords = [
          {
            word: "Ephemeral",
            type: "adjective",
            definition: "Lasting for a very short time; transitory.",
            example: "The ephemeral beauty of cherry blossoms makes them especially treasured.",
            synonyms: "fleeting, transient, momentary, brief",
            antonyms: "permanent, lasting, enduring, eternal"
          },
          {
            word: "Serendipity",
            type: "noun",
            definition: "The occurrence and development of events by chance in a happy or beneficial way.",
            example: "Finding his dream job while on vacation was pure serendipity.",
            synonyms: "chance, fortune, luck, providence",
            antonyms: "misfortune, bad luck, adversity, ill-fatedness"
          },
        ];
    }

    return NextResponse.json(defaultWords);
  }
}
