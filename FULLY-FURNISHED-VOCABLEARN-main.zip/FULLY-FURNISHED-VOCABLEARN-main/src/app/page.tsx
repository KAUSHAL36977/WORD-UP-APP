'use client'

import {fetchDailyWords} from '@/ai/flows/fetch-daily-words';
import {generateDailyQuiz} from '@/ai/flows/generate-daily-quiz';
import {generatePronunciationGuide} from '@/ai/flows/generate-pronunciation-guide';
import {Button} from '@/components/ui/button';
import {Card, CardContent, CardDescription, CardHeader, CardTitle} from '@/components/ui/card';
import {useEffect, useRef, useState} from 'react';
import {useToast} from '@/hooks/use-toast';
import {Tooltip, TooltipContent, TooltipProvider, TooltipTrigger} from '@/components/ui/tooltip';
import {Shuffle, Volume2} from 'lucide-react';
import {Tabs, TabsContent, TabsList, TabsTrigger} from "@/components/ui/tabs"
import styles from './page.module.css';


interface Word {
  word: string;
  definition: string;
  example: string;
  type: string;
  synonyms: string;
  antonyms: string;
}

interface Pronunciation {
  phoneticTranscription: string;
  audioUrl: string;
}

async function getWords(category?: string): Promise<Word[]> {
  try {
    const response = await fetch(`/api/words${category ? `?category=${category}` : ''}`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const words = await response.json();
    return words;
  } catch (error) {
    console.error('Failed to fetch words:', error);
    return [];
  }
}

export default function Home() {
  const [words, setWords] = useState<Word[]>([]);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  useEffect(() => {
    const loadWords = async () => {
      const fetchedWords = await getWords(activeCategory || undefined);
      setWords(fetchedWords);
    };

    loadWords();
  }, [activeCategory]);


  return (
    <TooltipProvider>
      <div className="container mx-auto py-10">
        <div className="flex justify-between items-center mb-5">
        <div className={styles.cubeContainer}>
        <div className={styles.cube}>
          <div className={`${styles.face} ${styles.front}`}>A</div>
          <div className={`${styles.face} ${styles.back}`}>B</div>
          <div className={`${styles.face} ${styles.right}`}>C</div>
          <div className={`${styles.face} ${styles.left}`}>D</div>
          <div className={`${styles.face} ${styles.top}`}>E</div>
          <div className={`${styles.face} ${styles.bottom}`}>F</div>
          <div className={`${styles.face} ${styles.front2}`}>G</div>
          <div className={`${styles.face} ${styles.back2}`}>H</div>
          <div className={`${styles.face} ${styles.right2}`}>I</div>
          <div className={`${styles.face} ${styles.left2}`}>J</div>
          <div className={`${styles.face} ${styles.top2}`}>K</div>
          <div className={`${styles.face} ${styles.bottom2}`}>L</div>
          <div className={`${styles.face} ${styles.front3}`}>M</div>
          <div className={`${styles.face} ${styles.back3}`}>N</div>
          <div className={`${styles.face} ${styles.right3}`}>O</div>
          <div className={`${styles.face} ${styles.left3}`}>P</div>
          <div className={`${styles.face} ${styles.top3}`}>Q</div>
          <div className={`${styles.face} ${styles.bottom3}`}>R</div>
          <div className={`${styles.face} ${styles.front4}`}>S</div>
          <div className={`${styles.face} ${styles.back4}`}>T</div>
          <div className={`${styles.face} ${styles.right4}`}>U</div>
          <div className={`${styles.face} ${styles.left4}`}>V</div>
          <div className={`${styles.face} ${styles.top4}`}>W</div>
          <div className={`${styles.face} ${styles.bottom4}`}>X</div>
           <div className={`${styles.face} ${styles.right5}`}>Y</div>
          <div className={`${styles.face} ${styles.left5}`}>Z</div>
        </div>
      </div>
          <h1 className="text-3xl font-bold text-center text-teal-500">VOCABLEARN - Daily English Words</h1>
          <RefreshButton/>
        </div>
        <Tabs defaultValue="science" className="w-[400px] mx-auto mb-5">
          <TabsList>
            <TabsTrigger value="science" onClick={() => setActiveCategory('Science')}>Science</TabsTrigger>
            <TabsTrigger value="technology" onClick={() => setActiveCategory('Technology')}>Technology</TabsTrigger>
            <TabsTrigger value="arts" onClick={() => setActiveCategory('Arts')}>Arts</TabsTrigger>
            <TabsTrigger value="literature" onClick={() => setActiveCategory('Literature')}>Literature</TabsTrigger>
          </TabsList>
        </Tabs>
        <WordList words={words}/>
      </div>
    </TooltipProvider>
  );
}

async function generateQuiz(words: Word[]) {
  try {
    const quizData = await generateDailyQuiz({words: words});
    return quizData.quiz;
  } catch (error) {
    console.error('Error generating quiz:', error);
    return 'Failed to generate the quiz. Please try again.';
  }
}

const WordList = ({words}: {words: Word[]}) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {words.map((wordItem, index) => (
        <WordCard key={index} wordItem={wordItem}/>
      ))}
    </div>
  );
};

const WordCard = ({wordItem}: {wordItem: Word}) => {
  const [pronunciation, setPronunciation] = useState<Pronunciation | null>(null);
  const {toast} = useToast();
  const audioRef = useRef<HTMLAudioElement>(null);


  const handlePronunciation = async (word: string) => {
    try {
      const pronunciationGuide = await generatePronunciationGuide({word});
      setPronunciation(pronunciationGuide);
      if (pronunciationGuide.audioUrl) {
        const audio = new Audio(pronunciationGuide.audioUrl);
        audio.play();
      }
    } catch (error) {
      console.error('Error generating pronunciation guide:', error);
      toast({
        title: 'Error',
        description: `Failed to get pronunciation for "${word}". Please try again.`,
        variant: 'destructive',
      });
    }
  };

  return (
    <Card className="rounded-lg shadow-md bg-gray-800 text-white">
      <CardHeader>
        <CardTitle className="text-xl text-blue-500">{wordItem.word}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription>
          <p>
            <strong>Definition:</strong> {wordItem.definition}
          </p>
          <p>
            <strong>Example:</strong> {wordItem.example}
          </p>
           <p>
            <strong>Type:</strong> {wordItem.type}
          </p>
          <p>
            <strong>Synonyms:</strong> {wordItem.synonyms}
          </p>
          <p>
            <strong>Antonyms:</strong> {wordItem.antonyms}
          </p>
          <div className="flex items-center justify-between mt-4">
            <Button
              variant="secondary"
              size="sm"
              className="rounded-full bg-blue-700 hover:bg-blue-500 text-white"
              onClick={() => handlePronunciation(wordItem.word)}
            >
              Pronounce
              <Volume2 className="ml-2 h-4 w-4"/>
            </Button>
            {pronunciation && (
              <audio controls ref={audioRef}>
                Your browser does not support the audio element.
              </audio>
            )}
          </div>
        </CardDescription>
      </CardContent>
    </Card>
  );
};

const RefreshButton = () => {
  const {toast} = useToast();

  const handleRefreshWords = async () => {
    try {
      // We can't directly refresh words from here because this is a client component and
      // Home is a server component.  Server actions can be used, but for simplicity, we'll
      // just reload the page.
      window.location.reload();
      toast({
        title: 'Words Refreshed',
        description: 'The daily words have been refreshed successfully.',
      });
    } catch (error) {
      console.error('Error refreshing words:', error);
      toast({
        title: 'Error',
        description: 'Failed to refresh words. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button variant="outline" size="icon" onClick={handleRefreshWords} aria-label="Refresh Words">
          <Shuffle className="h-4 w-4"/>
        </Button>
      </TooltipTrigger>
      <TooltipContent>
        <p>Refresh Words</p>
      </TooltipContent>
    </Tooltip>
  );
};

