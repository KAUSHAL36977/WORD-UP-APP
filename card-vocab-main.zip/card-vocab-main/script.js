// Global variables
let wordDatabase = [];
let currentWordIndex = 0;
let specialCard = $(".card.g");

// Initialize with current date
function setCurrentDate() {
    const date = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('current-date').textContent = date.toLocaleDateString('en-US', options);
}

// Update progress bar
function updateProgress() {
    if (wordDatabase.length === 0) return;
    const progressPercentage = ((currentWordIndex + 1) / wordDatabase.length) * 100;
    document.getElementById('progress').style.width = progressPercentage + '%';
}

// Load current word
function loadWord() {
    if (wordDatabase.length === 0) return;

    const word = wordDatabase[currentWordIndex];
    document.getElementById('word-front').textContent = word.word;
    document.getElementById('word-title').textContent = word.word;
    document.getElementById('word-type').textContent = word.type;
    document.getElementById('word-definition').textContent = word.definition;
    document.getElementById('word-example').textContent = word.example;
    document.getElementById('word-synonyms').innerHTML = '<strong>Synonyms:</strong> ' + word.synonyms;

    updateProgress();
}

// Card flip functionality
function toggle() {
    const flipCard = document.querySelector("#flipcard");
    if (flipCard.classList.contains("flip")) {
        hide();
    } else {
        specialCard.show();
        flipCard.classList.toggle("flip");
    }
}

function hide() {
    const flipCard = $("#flipcard");
    flipCard.addClass("hide").removeClass("flip");
    setTimeout(function () {
        flipCard.removeClass("hide");
        specialCard.hide();
    }, 900);
}

// Fetch words from the server
function fetchWords() {
    document.getElementById('word-front').textContent = "Loading...";

    fetch('/api/words')
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            wordDatabase = data;
            currentWordIndex = 0;
            loadWord();
        })
        .catch(error => {
            console.error('Error fetching words:', error);
            document.getElementById('word-front').textContent = "Error loading words";
            useDefaultWords();
        });
}

// Use default words if server fails
function useDefaultWords() {
    wordDatabase = [
        {
            word: "Ephemeral",
            type: "adjective",
            definition: "Lasting for a very short time; transitory.",
            example: "The ephemeral beauty of cherry blossoms makes them especially treasured.",
            synonyms: "fleeting, transient, momentary, brief"
        },
        {
            word: "Serendipity",
            type: "noun",
            definition: "The occurrence and development of events by chance in a happy or beneficial way.",
            example: "Finding his dream job while on vacation was pure serendipity.",
            synonyms: "chance, fortune, luck, providence"
        },
        {
            word: "Ubiquitous",
            type: "adjective",
            definition: "Present, appearing, or found everywhere.",
            example: "Cell phones have become ubiquitous in modern society.",
            synonyms: "omnipresent, pervasive, universal, prevalent"
        },
        {
            word: "Pernicious",
            type: "adjective",
            definition: "Having a harmful effect, especially in a gradual or subtle way.",
            example: "The pernicious influence of corruption undermined the entire organization.",
            synonyms: "harmful, destructive, damaging, detrimental"
        },
        {
            word: "Loquacious",
            type: "adjective",
            definition: "Tending to talk a great deal; garrulous.",
            example: "The loquacious tour guide entertained us with stories throughout the entire journey.",
            synonyms: "talkative, chatty, garrulous, verbose"
        },
        {
            word: "Mellifluous",
            type: "adjective",
            definition: "Sweet or musical; pleasant to hear.",
            example: "Her mellifluous voice made her a natural choice for the lead role in the musical.",
            synonyms: "sweet-sounding, dulcet, honeyed, euphonious"
        },
        {
            word: "Quintessential",
            type: "adjective",
            definition: "Representing the most perfect or typical example of a quality or class.",
            example: "The small town diner is the quintessential American eating establishment.",
            synonyms: "typical, classic, archetypal, definitive"
        },
        {
            word: "Sycophant",
            type: "noun",
            definition: "A person who acts obsequiously toward someone important in order to gain advantage.",
            example: "The CEO was surrounded by sycophants afraid to give honest feedback.",
            synonyms: "flatterer, toady, yes-man, bootlicker"
        },
        {
            word: "Pulchritude",
            type: "noun",
            definition: "Beauty; physical attractiveness (a formal or literary term).",
            example: "The art critic waxed lyrical about the pulchritude of the Renaissance paintings.",
            synonyms: "beauty, attractiveness, loveliness, fairness"
        },
        {
            word: "Perspicacious",
            type: "adjective",
            definition: "Having a ready insight into and understanding of things.",
            example: "Her perspicacious analysis of the problem led to an innovative solution.",
            synonyms: "perceptive, insightful, astute, shrewd"
        }
    ];
    loadWord();
}

// Initialize on document ready
$(document).ready(() => {
    setCurrentDate();
    fetchWords();
});// Global variables
let wordDatabase = [];
let currentWordIndex = 0;
let specialCard = $(".card.g");

// Initialize with current date
function setCurrentDate() {
    const date = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('current-date').textContent = date.toLocaleDateString('en-US', options);
}

// Update progress bar
function updateProgress() {
    if (wordDatabase.length === 0) return;
    const progressPercentage = ((currentWordIndex + 1) / wordDatabase.length) * 100;
    document.getElementById('progress').style.width = progressPercentage + '%';
}

// Load current word
function loadWord() {
    if (wordDatabase.length === 0) return;

    const word = wordDatabase[currentWordIndex];
    document.getElementById('word-front').textContent = word.word;
    document.getElementById('word-title').textContent = word.word;
    document.getElementById('word-type').textContent = word.type;
    document.getElementById('word-definition').textContent = word.definition;
    document.getElementById('word-example').textContent = word.example;
    document.getElementById('word-synonyms').innerHTML = '<strong>Synonyms:</strong> ' + word.synonyms;

    updateProgress();
}

// Card flip functionality
function toggle() {
    const flipCard = document.querySelector("#flipcard");
    if (flipCard.classList.contains("flip")) {
        hide();
    } else {
        specialCard.show();
        flipCard.classList.toggle("flip");
    }
}

function hide() {
    const flipCard = $("#flipcard");
    flipCard.addClass("hide").removeClass("flip");
    setTimeout(function () {
        flipCard.removeClass("hide");
        specialCard.hide();
    }, 900);
}

// Fetch words from the server
function fetchWords() {
    document.getElementById('word-front').textContent = "Loading...";

    fetch('/api/words')
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            wordDatabase = data;
            currentWordIndex = 0;
            loadWord();
        })
        .catch(error => {
            console.error('Error fetching words:', error);
            document.getElementById('word-front').textContent = "Error loading words";
            useDefaultWords();
        });
}

// Use default words if server fails
function useDefaultWords() {
    wordDatabase = [
        {
            word: "Ephemeral",
            type: "adjective",
            definition: "Lasting for a very short time; transitory.",
            example: "The ephemeral beauty of cherry blossoms makes them especially treasured.",
            synonyms: "fleeting, transient, momentary, brief"
        },
        {
            word: "Serendipity",
            type: "noun",
            definition: "The occurrence and development of events by chance in a happy or beneficial way.",
            example: "Finding his dream job while on vacation was pure serendipity.",
            synonyms: "chance, fortune, luck, providence"
        },
        {
            word: "Ubiquitous",
            type: "adjective",
            definition: "Present, appearing, or found everywhere.",
            example: "Cell phones have become ubiquitous in modern society.",
            synonyms: "omnipresent, pervasive, universal, prevalent"
        },
        {
            word: "Pernicious",
            type: "adjective",
            definition: "Having a harmful effect, especially in a gradual or subtle way.",
            example: "The pernicious influence of corruption undermined the entire organization.",
            synonyms: "harmful, destructive, damaging, detrimental"
        },
        {
            word: "Loquacious",
            type: "adjective",
            definition: "Tending to talk a great deal; garrulous.",
            example: "The loquacious tour guide entertained us with stories throughout the entire journey.",
            synonyms: "talkative, chatty, garrulous, verbose"
        },
        {
            word: "Mellifluous",
            type: "adjective",
            definition: "Sweet or musical; pleasant to hear.",
            example: "Her mellifluous voice made her a natural choice for the lead role in the musical.",
            synonyms: "sweet-sounding, dulcet, honeyed, euphonious"
        },
        {
            word: "Quintessential",
            type: "adjective",
            definition: "Representing the most perfect or typical example of a quality or class.",
            example: "The small town diner is the quintessential American eating establishment.",
            synonyms: "typical, classic, archetypal, definitive"
        },
        {
            word: "Sycophant",
            type: "noun",
            definition: "A person who acts obsequiously toward someone important in order to gain advantage.",
            example: "The CEO was surrounded by sycophants afraid to give honest feedback.",
            synonyms: "flatterer, toady, yes-man, bootlicker"
        },
        {
            word: "Pulchritude",
            type: "noun",
            definition: "Beauty; physical attractiveness (a formal or literary term).",
            example: "The art critic waxed lyrical about the pulchritude of the Renaissance paintings.",
            synonyms: "beauty, attractiveness, loveliness, fairness"
        },
        {
            word: "Perspicacious",
            type: "adjective",
            definition: "Having a ready insight into and understanding of things.",
            example: "Her perspicacious analysis of the problem led to an innovative solution.",
            synonyms: "perceptive, insightful, astute, shrewd"
        }
    ];
    loadWord();
}

// Initialize on document ready
$(document).ready(() => {
    setCurrentDate();
    fetchWords();
});
