# card-vocab
vocab on card format 
