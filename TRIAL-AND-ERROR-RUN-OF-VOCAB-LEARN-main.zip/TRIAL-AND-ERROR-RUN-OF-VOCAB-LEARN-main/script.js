// Placeholder for future JavaScript functionality
document.addEventListener("DOMContentLoaded", () => {
    console.log("VocabLearn site loaded!");
});
